package ie.wit.ictskills.shapes;

public interface Measurable 
{
	double perimeter();
}