package ie.wit.ictskills.shapes;
// TODO Task 4: Complete Ellipse, inherit Shapes, implement Measurable, subclass Circle.
import ie.wit.ictskills.util.ellipse.EllipseMeasure;

import java.awt.geom.*;

/**
 * An ellipse that can be manipulated and that draws itself on a canvas.
 * 
 * @author   
 * 
 * @version  
 */

public class Ellipse 

{
    protected int xdiameter;
    private int ydiameter;

//   @Override
//	public double perimeter() 
//	{   
//		return EllipseMeasure.perimeter(xdiameter, ydiameter);
//	}

}
