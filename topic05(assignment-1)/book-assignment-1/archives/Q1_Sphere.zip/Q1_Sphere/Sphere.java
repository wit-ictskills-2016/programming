
/**
 * Write a description of class Sphere here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sphere
{
  double radius = -1.0;
  static double numberSpheres = -10;
    
}
